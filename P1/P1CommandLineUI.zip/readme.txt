I chose to do the extra credit for Project 1 by implementing a command line UI, found in p1.java. 

It can be run much like the no-extra-credit method but with p1 instead of ProgramLauncher, requiring the same jar and properties file, with a call like the following on Windows Terminal:

javac *.java; java -cp ";./db2jcc4.jar" p1 ./db.properties;

I did it this way so the non-extra-credit method of testing like

javac *.java; java -cp ";./db2jcc4.jar" ProgramLauncher ./db.properties;

would still produce the exact same output as test_full.out.

Running p1 does NOT run the test commands in db.properties. I did it this way so the user could start from scratch by just running p1, or start with the test data by doing a ProgramLauncher call before the p1 call if they want. 